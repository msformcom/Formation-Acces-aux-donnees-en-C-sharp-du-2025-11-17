﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests.DAL
{
    public class Adresse
    {
        public string? Ligne { get; set; }
        public string?  CP { get; set; }
        public string?  Ville { get; set; }
    }
}
